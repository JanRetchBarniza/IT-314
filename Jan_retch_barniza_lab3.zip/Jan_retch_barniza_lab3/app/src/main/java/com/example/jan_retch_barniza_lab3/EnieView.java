package com.example.jan_retch_barniza_lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EnieView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enie_view);
    }
}